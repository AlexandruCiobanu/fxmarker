/*********************************************************************************************************************************/
/**												${project.name} version ${project.version} (${currentDate})				   									**/
/**													by Alex Ciobanu						   										**/
/*********************************************************************************************************************************/

Copyright 2008 - 2009 Alex Ciobanu (http://code.google.com/p/flexxb)

CONTENTS

${project.name}-${release.version}-${today}-bin.zip - contains the ${project.name} library along with the test 
							application
			/bin/ 				 - SWC file and test application directory
			/bin/test/ 			 - the test application
			/bin/flexunit        - flexunit automated test reports
			/doc/ 				 - ASDOC
			/samples/			 - samples showing ${project.name}'s features 
			/README.txt			 - version release notes

${project.name}-${release.version}-${today}-src.zip - contains source files
			/${project.name}/	 - ${project.name} project sources
			/${project.name}Test - ${project.name} test application sources

DESCRIPTION

FEATURES

USAGE

KNOWN LIMITATIONS

RELEASE NOTES