/*********************************************************************************************************************************/
/**												FxMarker version 0.1 (20-07-2009)				   									**/
/**													by Alex Ciobanu						   										**/
/*********************************************************************************************************************************/

Copyright 2008 - 2009 Alex Ciobanu (http://code.google.com/p/flexxb)

CONTENTS

FxMarker-0_1-20072009-bin.zip - contains the FxMarker library along with the test 
							application
			/bin/ 				 - SWC file and test application directory
			/bin/test/ 			 - the test application
			/bin/flexunit        - flexunit automated test reports
			/doc/ 				 - ASDOC
			/samples/			 - samples showing FxMarker's features 
			/README.txt			 - version release notes

FxMarker-0_1-20072009-src.zip - contains source files
			/FxMarker/	 - FxMarker project sources
			/FxMarkerTest - FxMarker test application sources

DESCRIPTION

FEATURES

USAGE

KNOWN LIMITATIONS

RELEASE NOTES